package com.mashaswape

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.io.File
import java.util.concurrent.CountDownLatch
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private lateinit var consent: CheckBox
    private lateinit var askFaces: CheckBox
    private lateinit var allFaces: CheckBox
    private lateinit var enhSpinner: Spinner
    private lateinit var strengthEdit: EditText
    private lateinit var photoPxEdit: EditText
    private lateinit var outPxEdit: EditText
    private lateinit var jpgEdit: EditText
    private lateinit var startEdit: EditText
    private lateinit var lenEdit: EditText
    private lateinit var resSpinner: Spinner
    private lateinit var fpsEdit: EditText
    private lateinit var qualSpinner: Spinner

    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }
    private val needed = listOf("det_10g.onnx", "w600k_r50.onnx", "inswapper_128.onnx", "emap.bin")
    private val optional = listOf("gfpgan_1.4.onnx", "codeformer.onnx")
    private var sources = listOf<Uri>()
    private var targets = listOf<Uri>()
    private var engine: FaceEngine? = null
    @Volatile private var busy = false

    private class Pick(val faces: List<Face>, val all: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            keepScreenOn = true
            setBackgroundColor(Color.BLACK)
        }
        root.addView(TextView(this).apply {
            text = "*#SwAppEr.PrO#*  v2.0"
            textSize = 22f
            setTextColor(Color.WHITE)
        })
        status = TextView(this).apply { setPadding(0, 16, 0, 16); setTextColor(Color.rgb(0, 220, 150)) }
        root.addView(status)

        consent = CheckBox(this).apply {
            text = "Ich nutze das nur mit ausdrücklicher Einwilligung der abgebildeten Personen. " +
                "Keine Täuschung, keine Rufschädigung, keine Veröffentlichung ohne Erlaubnis."
        }
        root.addView(consent)

        root.addView(button("1. Modelle importieren (4 Pflicht + Verbesserer)") { pick(1, "*/*", true, null) })
        root.addView(button("2. Quellfotos wählen (mehrere, eine Person)") { pick(2, "image/*", true, null) })
        root.addView(button("3. Ziel wählen: Fotos und/oder Videos") {
            pick(3, "*/*", true, arrayOf("image/*", "video/*"))
        })

        askFaces = CheckBox(this).apply {
            text = "Vorher fragen, welche Gesichter getauscht werden (Fotos und Videos)"
            isChecked = true
        }
        root.addView(askFaces)
        allFaces = CheckBox(this).apply {
            text = "Ohne Rückfrage: alle Gesichter tauschen (sonst nur das größte)"
        }
        root.addView(allFaces)

        // ---- Foto-Einstellungen ----
        root.addView(heading("Foto-Einstellungen"))
        root.addView(label("Verarbeitungsgröße, längste Seite in Pixeln (Standard 2400)"))
        photoPxEdit = numField("2400"); root.addView(photoPxEdit)
        root.addView(label("Ausgabegröße, längste Seite in Pixeln (0 = wie verarbeitet)"))
        outPxEdit = numField("0"); root.addView(outPxEdit)
        root.addView(label("JPEG-Qualität in % (50 bis 100, Standard 95)"))
        jpgEdit = numField("95"); root.addView(jpgEdit)
        root.addView(label("Gesichts-Verbesserer (nur Fotos)"))
        enhSpinner = spinner(arrayOf("Aus", "GFPGAN 1.4", "CodeFormer", "Beide (zwei Bilder zum Vergleichen)"))
        root.addView(enhSpinner)
        root.addView(label("Stärke des Verbesserers in % (Standard 80)"))
        strengthEdit = numField("80"); root.addView(strengthEdit)

        // ---- Video-Einstellungen ----
        root.addView(heading("Video-Einstellungen"))
        root.addView(label("Start im Video in Sekunden (Standard 0)"))
        startEdit = numField("0"); root.addView(startEdit)
        root.addView(label("Länge in Sekunden (0 = bis zum Ende, Standard 10)"))
        lenEdit = numField("10"); root.addView(lenEdit)
        root.addView(label("Auflösung der Ausgabe"))
        resSpinner = spinner(arrayOf("480p (schnell)", "720p", "1080p (langsam)"))
        resSpinner.setSelection(1)
        root.addView(resSpinner)
        root.addView(label("Bilder pro Sekunde (5 bis 30, weniger = schneller)"))
        fpsEdit = numField("10"); root.addView(fpsEdit)
        root.addView(label("Videoqualität (Dateigröße)"))
        qualSpinner = spinner(arrayOf("Niedrig", "Mittel", "Hoch"))
        qualSpinner.setSelection(1)
        root.addView(qualSpinner)

        root.addView(button("TAUSCHEN") { runSwap() })

        preview = ImageView(this).apply {
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(preview)
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(root) })
        say(modelStatus())
    }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 17f
        setTextColor(Color.rgb(0, 200, 150))
        setPadding(0, 36, 0, 0)
    }

    private fun label(t: String) = TextView(this).apply { text = t; setPadding(0, 20, 0, 0) }

    private fun numField(v: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(v)
    }

    private fun spinner(items: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun say(s: String) = runOnUiThread { status.text = s }

    private fun intOf(e: EditText, def: Int, lo: Int, hi: Int): Int =
        e.text.toString().toIntOrNull()?.coerceIn(lo, hi) ?: def

    private fun modelStatus(): String {
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) return "Fehlende Modelle: ${missing.joinToString(", ")}"
        val enh = optional.filter { File(modelDir, it).exists() }
        return "Modelle vorhanden. " +
            if (enh.isEmpty()) "Kein Verbesserer importiert." else "Verbesserer: ${enh.joinToString(", ")}."
    }

    private fun pick(req: Int, mime: String, multi: Boolean, mimes: Array<String>?) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multi)
            if (mimes != null) putExtra(Intent.EXTRA_MIME_TYPES, mimes)
        }
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        when (req) {
            1 -> importModels(uris)
            2 -> { sources = uris; say("${uris.size} Quellfoto(s) gewählt.") }
            3 -> { targets = uris; say("${uris.size} Ziel-Datei(en) gewählt.") }
        }
    }

    private fun displayName(u: Uri): String? =
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }

    /** Erkennt auch umbenannte Downloads wie "gfpgan_1.4 (1).onnx". */
    private fun canonicalName(raw: String): String? {
        val clean = raw.replace(Regex(" \\(\\d+\\)"), "")
        return (needed + optional).firstOrNull { it == clean }
    }

    private fun importModels(uris: List<Uri>) {
        Thread {
            try {
                for (u in uris) {
                    val raw = displayName(u) ?: continue
                    val name = canonicalName(raw)
                    if (name == null) { say("Übersprungen: $raw"); continue }
                    say("Kopiere $name ...")
                    contentResolver.openInputStream(u)?.use { inp ->
                        File(modelDir, name).outputStream().use { out -> inp.copyTo(out) }
                    }
                }
                engine = null
                say(modelStatus())
            } catch (e: Throwable) {
                say("Fehler beim Import: ${e.message}")
            }
        }.start()
    }

    private fun isVideo(u: Uri): Boolean = contentResolver.getType(u)?.startsWith("video/") == true

    private fun scaleTo(b: Bitmap, px: Int): Bitmap {
        val m = max(b.width, b.height)
        if (px <= 0 || m == px) return b
        val s = px.toFloat() / m
        return Bitmap.createScaledBitmap(
            b, max(1, (b.width * s).toInt()), max(1, (b.height * s).toInt()), true
        )
    }

    private fun load(u: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: return null
        val orient = contentResolver.openInputStream(u)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        } ?: 1
        val deg = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        val rotated = if (deg == 0f) bmp else {
            val m = Matrix().apply { postRotate(deg) }
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return if (max(rotated.width, rotated.height) > maxSide) scaleTo(rotated, maxSide) else rotated
    }

    /** Ein Bild aus dem Video (für die Gesichts-Auswahl). */
    private fun videoFrame(u: Uri, startSec: Int): Bitmap? {
        val m = MediaMetadataRetriever()
        return try {
            m.setDataSource(this, u)
            val f = m.getFrameAtTime(startSec * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST)
            f?.copy(Bitmap.Config.ARGB_8888, true)?.let { scaleTo(it, 1280).copy(Bitmap.Config.ARGB_8888, true) }
        } catch (e: Exception) {
            null
        } finally {
            m.release()
        }
    }

    private fun save(b: Bitmap, tag: String, quality: Int) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "swapperpro_${System.currentTimeMillis()}_$tag.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SwApperPro")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    }

    /** Zeigt das Bild mit nummerierten Rahmen und wartet, bis du auswählst. null = überspringen. */
    private fun askWhichFaces(b: Bitmap, faces: List<Face>, label: String): Pick? {
        val latch = CountDownLatch(1)
        var result: Pick? = null
        runOnUiThread {
            val v = FacePickView(this, b, faces)
            val holder = ScrollView(this).apply { addView(v) }
            AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("$label: Gesichter antippen (grün = wird getauscht)")
                .setView(holder)
                .setPositiveButton("Tauschen") { _, _ ->
                    result = Pick(faces.filterIndexed { i, _ -> v.selected[i] }, false)
                    latch.countDown()
                }
                .setNeutralButton("Alle") { _, _ -> result = Pick(faces, true); latch.countDown() }
                .setNegativeButton("Überspringen") { _, _ -> result = null; latch.countDown() }
                .setCancelable(false)
                .show()
        }
        latch.await()
        return result
    }

    private fun runSwap() {
        if (busy) return
        if (!consent.isChecked) { say("Bitte zuerst die Einwilligung bestätigen."); return }
        if (sources.isEmpty() || targets.isEmpty()) { say("Bitte Quellfotos und Ziel wählen."); return }
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) { say("Fehlende Modelle: ${missing.joinToString(", ")}"); return }

        val enhModels: List<Pair<String, String>> = when (enhSpinner.selectedItemPosition) {
            1 -> listOf("gfpgan_1.4.onnx" to "gfpgan")
            2 -> listOf("codeformer.onnx" to "codeformer")
            3 -> listOf("gfpgan_1.4.onnx" to "gfpgan", "codeformer.onnx" to "codeformer")
            else -> emptyList()
        }
        val missEnh = enhModels.map { it.first }.filter { !File(modelDir, it).exists() }
        if (missEnh.isNotEmpty()) {
            say("Verbesserer-Datei fehlt: ${missEnh.joinToString(", ")}. Bitte über Schritt 1 importieren.")
            return
        }

        val strength = intOf(strengthEdit, 80, 0, 100) / 100f
        val photoPx = intOf(photoPxEdit, 2400, 480, 6000)
        val outPx = intOf(outPxEdit, 0, 0, 8000)
        val jpg = intOf(jpgEdit, 95, 50, 100)
        val startSec = intOf(startEdit, 0, 0, 100000)
        val lenSec = intOf(lenEdit, 10, 0, 100000)
        val vMax = when (resSpinner.selectedItemPosition) { 0 -> 854; 1 -> 1280; else -> 1920 }
        val fps = intOf(fpsEdit, 10, 5, 30)
        val bpp = when (qualSpinner.selectedItemPosition) { 0 -> 0.10f; 1 -> 0.17f; else -> 0.30f }
        val all = allFaces.isChecked
        val ask = askFaces.isChecked

        busy = true
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "swapperpro:work")
        wl.acquire(12L * 60 * 60 * 1000)

        Thread {
            try {
                say("Lade Modelle (beim ersten Mal dauert das) ...")
                val eng = engine ?: FaceEngine(modelDir).also { engine = it }

                val embs = ArrayList<FloatArray>()
                for ((i, u) in sources.withIndex()) {
                    say("Quellgesicht ${i + 1}/${sources.size} ...")
                    val b = load(u, 2400) ?: continue
                    val f = eng.detect(b).maxByOrNull { it.area } ?: continue
                    embs.add(eng.embed(b, f))
                }
                if (embs.isEmpty()) { say("In den Quellfotos wurde kein Gesicht gefunden."); return@Thread }
                val latent = eng.makeLatent(embs)

                var last: Bitmap? = null
                var done = 0
                for ((i, u) in targets.withIndex()) {
                    val label = "Ziel ${i + 1}/${targets.size}"

                    if (isVideo(u)) {
                        var refs: List<FloatArray>? = null
                        var vAll = all
                        if (ask) {
                            say("$label: Startbild laden ...")
                            val fb = videoFrame(u, startSec)
                            if (fb == null) { say("$label: Startbild nicht lesbar."); continue }
                            val ff = eng.detect(fb).sortedByDescending { it.area }
                            if (ff.isEmpty()) { say("$label: im Startbild kein Gesicht gefunden."); continue }
                            val p = askWhichFaces(fb, ff, "$label (Video)")
                            if (p == null || (!p.all && p.faces.isEmpty())) continue
                            if (p.all) vAll = true else refs = p.faces.map { eng.embed(fb, it) }
                        }
                        say("$label (Video) wird bearbeitet ...")
                        val opt = VideoOptions(startSec, lenSec, vMax, fps, bpp, vAll, refs)
                        val okVideo = VideoProcessor.process(this, u, eng, latent, opt) { msg ->
                            say("$label: $msg")
                        }
                        if (okVideo) done++
                        continue
                    }

                    say("$label: Gesichter suchen ...")
                    val b = load(u, photoPx) ?: continue
                    val found = eng.detect(b).sortedByDescending { it.area }
                    if (found.isEmpty()) { say("$label: kein Gesicht gefunden."); continue }
                    val chosen: List<Face> = if (ask) {
                        val p = askWhichFaces(b, found, label)
                        when {
                            p == null -> emptyList()
                            p.all -> found
                            else -> p.faces
                        }
                    } else if (all) found else found.take(1)
                    if (chosen.isEmpty()) continue

                    say("$label: Gesicht wird getauscht ...")
                    var swapped = b
                    for (f in chosen) swapped = eng.swap(swapped, f, latent)

                    if (enhModels.isEmpty()) {
                        val outBmp = scaleTo(swapped, outPx)
                        save(outBmp, "$i", jpg)
                        last = outBmp
                    } else {
                        for ((file, tag) in enhModels) {
                            say("$label: Verbesserer $tag läuft (kann etwas dauern) ...")
                            var out = swapped
                            for (f in chosen) out = eng.enhance(out, f, file, strength)
                            val outBmp = scaleTo(out, outPx)
                            save(outBmp, "${i}_$tag", jpg)
                            last = outBmp
                        }
                    }
                    done++
                }
                val shown = last
                if (shown != null) runOnUiThread { preview.setImageBitmap(shown) }
                say("Fertig: $done von ${targets.size} Datei(en) gespeichert (Bilder/SwApperPro bzw. Filme/SwApperPro).")
            } catch (e: Throwable) {
                say("Fehler: ${e.message}")
            } finally {
                if (wl.isHeld) wl.release()
                busy = false
            }
        }.start()
    }
}

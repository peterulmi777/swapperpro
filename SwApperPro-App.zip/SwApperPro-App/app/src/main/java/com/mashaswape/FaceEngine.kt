package com.mashaswape

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.DoubleBuffer
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Face(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val score: Float, val kps: FloatArray
) {
    val area: Float get() = (x2 - x1) * (y2 - y1)
}

/**
 * Erkennung (SCRFD det_10g), Gesichts-Embedding (ArcFace w600k_r50), Tausch (InSwapper 128)
 * und optional Gesichts-Verbesserung (GFPGAN 1.4 / CodeFormer, 512 px).
 */
class FaceEngine(private val dir: File) {
    private val env = OrtEnvironment.getEnvironment()
    private val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
    private val det = env.createSession(File(dir, "det_10g.onnx").absolutePath, opts)
    private val rec = env.createSession(File(dir, "w600k_r50.onnx").absolutePath, opts)
    private val swp = env.createSession(File(dir, "inswapper_128.onnx").absolutePath, opts)
    private val enhancers = HashMap<String, OrtSession>()
    private val emap = FloatArray(512 * 512).also {
        ByteBuffer.wrap(File(dir, "emap.bin").readBytes()).order(ByteOrder.LITTLE_ENDIAN)
            .asFloatBuffer().get(it)
    }

    // ArcFace-Vorlage für 112 px (insightface face_align.arcface_dst)
    private val dst112 = floatArrayOf(
        38.2946f, 51.6963f, 73.5318f, 51.5014f, 56.0252f,
        71.7366f, 41.5493f, 92.3655f, 70.7299f, 92.2041f
    )

    // InSwapper 128: insightface estimate_norm(image_size=128): Maßstab 1.0, x-Verschiebung +8 px
    private val dst128 = FloatArray(10) { if (it % 2 == 0) dst112[it] + 8f else dst112[it] }

    // FFHQ-Vorlage der Verbesserer (FaceFusion "ffhq_512", normiert) mal 512
    private val dst512 = floatArrayOf(
        0.37691676f, 0.46864664f, 0.62285697f, 0.46912813f, 0.50123859f,
        0.61331904f, 0.39308822f, 0.72541100f, 0.61150205f, 0.72490465f
    ).let { t -> FloatArray(10) { t[it] * 512f } }

    private fun tensor(d: FloatArray, shape: LongArray) =
        OnnxTensor.createTensor(env, FloatBuffer.wrap(d), shape)

    private fun OnnxTensor.toArray(): FloatArray {
        val fb = this.floatBuffer
        val a = FloatArray(fb.remaining())
        fb.get(a)
        return a
    }

    private fun normalize(v: FloatArray): FloatArray {
        var s = 0.0
        for (x in v) s += (x * x).toDouble()
        val n = sqrt(s).toFloat() + 1e-9f
        return FloatArray(v.size) { v[it] / n }
    }

    /** Ähnlichkeitstransformation (Drehung + Skalierung + Verschiebung) von src nach dst, 5 Punkte. */
    private fun similarity(src: FloatArray, dst: FloatArray): Matrix {
        var mpx = 0.0; var mpy = 0.0; var mqx = 0.0; var mqy = 0.0
        for (i in 0 until 5) {
            mpx += src[2 * i]; mpy += src[2 * i + 1]
            mqx += dst[2 * i]; mqy += dst[2 * i + 1]
        }
        mpx /= 5; mpy /= 5; mqx /= 5; mqy /= 5
        var num1 = 0.0; var num2 = 0.0; var den = 0.0
        for (i in 0 until 5) {
            val px = src[2 * i] - mpx; val py = src[2 * i + 1] - mpy
            val qx = dst[2 * i] - mqx; val qy = dst[2 * i + 1] - mqy
            num1 += px * qx + py * qy
            num2 += px * qy - py * qx
            den += px * px + py * py
        }
        val a = num1 / den
        val b = num2 / den
        val tx = mqx - (a * mpx - b * mpy)
        val ty = mqy - (b * mpx + a * mpy)
        return Matrix().apply {
            setValues(
                floatArrayOf(
                    a.toFloat(), (-b).toFloat(), tx.toFloat(),
                    b.toFloat(), a.toFloat(), ty.toFloat(),
                    0f, 0f, 1f
                )
            )
        }
    }

    private fun alignTo(bmp: Bitmap, kps: FloatArray, dst: FloatArray, size: Int): Pair<Bitmap, Matrix> {
        val m = similarity(kps, dst)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return Pair(out, m)
    }

    private fun chw(bmp: Bitmap, mean: Float, std: Float): FloatArray {
        val n = bmp.width * bmp.height
        val px = IntArray(n)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val out = FloatArray(3 * n)
        for (i in 0 until n) {
            val c = px[i]
            out[i] = (((c shr 16) and 255) - mean) / std
            out[n + i] = (((c shr 8) and 255) - mean) / std
            out[2 * n + i] = ((c and 255) - mean) / std
        }
        return out
    }

    // ---------------- Erkennung ----------------
    fun detect(bmp: Bitmap): List<Face> {
        val size = 640
        val ratio = min(size.toFloat() / bmp.width, size.toFloat() / bmp.height)
        val nw = max(1, (bmp.width * ratio).toInt())
        val nh = max(1, (bmp.height * ratio).toInt())
        val scaled = Bitmap.createScaledBitmap(bmp, nw, nh, true)
        val px = IntArray(nw * nh)
        scaled.getPixels(px, 0, nw, 0, 0, nw, nh)

        val plane = size * size
        val data = FloatArray(3 * plane) { -127.5f / 128f }
        for (y in 0 until nh) for (x in 0 until nw) {
            val c = px[y * nw + x]
            val o = y * size + x
            data[o] = (((c shr 16) and 255) - 127.5f) / 128f
            data[plane + o] = (((c shr 8) and 255) - 127.5f) / 128f
            data[2 * plane + o] = ((c and 255) - 127.5f) / 128f
        }

        val found = ArrayList<Face>()
        tensor(data, longArrayOf(1, 3, size.toLong(), size.toLong())).use { t ->
            det.run(mapOf(det.inputNames.first() to t)).use { res ->
                val strides = intArrayOf(8, 16, 32)
                for ((idx, stride) in strides.withIndex()) {
                    val scores = (res[idx] as OnnxTensor).toArray()
                    val boxes = (res[idx + 3] as OnnxTensor).toArray()
                    val kp = (res[idx + 6] as OnnxTensor).toArray()
                    val g = size / stride
                    for (k in 0 until g * g * 2) {
                        if (scores[k] < 0.5f) continue
                        val a = k / 2
                        val cx = ((a % g) * stride).toFloat()
                        val cy = ((a / g) * stride).toFloat()
                        val pts = FloatArray(10)
                        for (j in 0 until 5) {
                            pts[2 * j] = (cx + kp[10 * k + 2 * j] * stride) / ratio
                            pts[2 * j + 1] = (cy + kp[10 * k + 2 * j + 1] * stride) / ratio
                        }
                        found.add(
                            Face(
                                (cx - boxes[4 * k] * stride) / ratio,
                                (cy - boxes[4 * k + 1] * stride) / ratio,
                                (cx + boxes[4 * k + 2] * stride) / ratio,
                                (cy + boxes[4 * k + 3] * stride) / ratio,
                                scores[k], pts
                            )
                        )
                    }
                }
            }
        }
        return nms(found)
    }

    private fun iou(a: Face, b: Face): Float {
        val ix = max(0f, min(a.x2, b.x2) - max(a.x1, b.x1))
        val iy = max(0f, min(a.y2, b.y2) - max(a.y1, b.y1))
        val i = ix * iy
        return i / (a.area + b.area - i + 1e-6f)
    }

    private fun nms(all: List<Face>): List<Face> {
        val keep = ArrayList<Face>()
        for (c in all.sortedByDescending { it.score }) {
            if (keep.none { iou(it, c) > 0.4f }) keep.add(c)
        }
        return keep
    }

    // ---------------- Quellgesicht ----------------
    fun embed(bmp: Bitmap, f: Face): FloatArray {
        val (crop, _) = alignTo(bmp, f.kps, dst112, 112)
        val data = chw(crop, 127.5f, 127.5f)
        return tensor(data, longArrayOf(1, 3, 112, 112)).use { t ->
            rec.run(mapOf(rec.inputNames.first() to t)).use { r ->
                normalize((r[0] as OnnxTensor).toArray())
            }
        }
    }

    /** Mittelt mehrere Fotos zu EINEM Quellgesicht und rechnet es für InSwapper um. */
    fun makeLatent(embs: List<FloatArray>): FloatArray {
        val avg = FloatArray(512)
        for (e in embs) for (i in 0 until 512) avg[i] += e[i]
        val m = normalize(avg)
        val out = FloatArray(512)
        for (i in 0 until 512) {
            val v = m[i]
            val row = i * 512
            for (j in 0 until 512) out[j] += v * emap[row + j]
        }
        return normalize(out)
    }

    /** Kosinus-Ähnlichkeit zweier (bereits normalisierter) Embeddings: 1.0 = gleich. */
    fun similarity(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    // ---------------- Tausch ----------------
    fun swap(target: Bitmap, f: Face, latent: FloatArray): Bitmap {
        val (crop, m) = alignTo(target, f.kps, dst128, 128)
        val inv = Matrix()
        if (!m.invert(inv)) return target

        val input = chw(crop, 0f, 255f)
        val fake = tensor(input, longArrayOf(1, 3, 128, 128)).use { t ->
            tensor(latent, longArrayOf(1, 512)).use { s ->
                swp.run(mapOf("target" to t, "source" to s)).use { r ->
                    (r[0] as OnnxTensor).toArray()
                }
            }
        }

        val plane = 128 * 128
        val px = IntArray(plane)
        for (y in 0 until 128) for (x in 0 until 128) {
            val i = y * 128 + x
            val r = (fake[i] * 255f).coerceIn(0f, 255f).toInt()
            val g = (fake[plane + i] * 255f).coerceIn(0f, 255f).toInt()
            val b = (fake[2 * plane + i] * 255f).coerceIn(0f, 255f).toInt()
            val dx = (x - 64f) / 54f
            val dy = (y - 72f) / 56f
            val rr = sqrt(dx * dx + dy * dy)
            val a = ((1f - rr) / 0.3f).coerceIn(0f, 1f)
            px[i] = ((a * 255f).toInt() shl 24) or (r shl 16) or (g shl 8) or b
        }
        val fb = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        fb.setPixels(px, 0, 128, 0, 0, 128, 128)

        val result = target.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(result).drawBitmap(fb, inv, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }

    // ---------------- Verbesserer (GFPGAN 1.4 / CodeFormer) ----------------
    /**
     * Schärft/rekonstruiert ein Gesicht (512 px, Eingabe/Ausgabe RGB im Bereich -1..1).
     * strength 0..1 = Mischung aus verbessertem und ursprünglichem Gesicht (FaceFusion-Standard 0.8).
     */
    fun enhance(bmp: Bitmap, f: Face, modelName: String, strength: Float): Bitmap {
        val sess = enhancers.getOrPut(modelName) {
            env.createSession(File(dir, modelName).absolutePath, opts)
        }
        val (crop, m) = alignTo(bmp, f.kps, dst512, 512)
        val inv = Matrix()
        if (!m.invert(inv)) return bmp

        val data = chw(crop, 127.5f, 127.5f)
        val tImg = tensor(data, longArrayOf(1, 3, 512, 512))
        var tW: OnnxTensor? = null
        val out: FloatArray = try {
            val inputs = HashMap<String, OnnxTensor>()
            for (n in sess.inputNames) {
                if (n == "weight") {
                    // CodeFormer: zusätzlicher Eingang "weight" (double), FaceFusion nutzt 1
                    val w = OnnxTensor.createTensor(env, DoubleBuffer.wrap(doubleArrayOf(1.0)), longArrayOf(1))
                    tW = w
                    inputs[n] = w
                } else {
                    inputs[n] = tImg
                }
            }
            sess.run(inputs).use { r -> (r[0] as OnnxTensor).toArray() }
        } finally {
            tImg.close()
            tW?.close()
        }

        val plane = 512 * 512
        val px = IntArray(plane)
        for (y in 0 until 512) for (x in 0 until 512) {
            val i = y * 512 + x
            val r = (((out[i].coerceIn(-1f, 1f) + 1f) / 2f) * 255f + 0.5f).toInt()
            val g = (((out[plane + i].coerceIn(-1f, 1f) + 1f) / 2f) * 255f + 0.5f).toInt()
            val b = (((out[2 * plane + i].coerceIn(-1f, 1f) + 1f) / 2f) * 255f + 0.5f).toInt()
            val d = min(min(x, y), min(511 - x, 511 - y)).toFloat()
            val a = ((d - 40f) / 72f).coerceIn(0f, 1f) * strength
            px[i] = ((a * 255f).toInt() shl 24) or (r shl 16) or (g shl 8) or b
        }
        val eb = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        eb.setPixels(px, 0, 512, 0, 0, 512, 512)

        val result = bmp.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(result).drawBitmap(eb, inv, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }
}

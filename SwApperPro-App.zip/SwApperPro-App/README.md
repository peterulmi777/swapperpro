# *#SwAppEr.PrO#* v2.0 – Face-Swap-App für Android (offline, dunkles Design)

Neu: eigene App-ID (parallel zur alten App installierbar), schwarzes Design,
Foto-Größe/Qualität, Video mit Start, Länge, Auflösung, Bildrate, Qualität,
Gesichtsauswahl für Fotos UND Videos (Personen werden im Video per Gesichtserkennung wiedergefunden).

Modelle (in der App unter Schritt 1 importieren):
Pflicht: det_10g.onnx, w600k_r50.onnx, inswapper_128.onnx, emap.bin
Optional: gfpgan_1.4.onnx, codeformer.onnx

Ergebnisse: Bilder/SwApperPro und Filme/SwApperPro.
Nur mit ausdrücklicher Einwilligung der abgebildeten Personen verwenden.

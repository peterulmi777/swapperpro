package com.mashaswape

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Ein zu tauschendes Gesicht im Bild; person = Index der Quellperson. */
class Track(val face: Face, val person: Int)

/**
 * Einfache Nachverfolgung zwischen zwei Suchbildern: das Gesicht wird per Blockvergleich
 * (Summe der Helligkeitsunterschiede) im verkleinerten Graubild wiedergefunden.
 */
object Tracker {
    class Gray(val w: Int, val h: Int, val d: IntArray, val scale: Float)

    private const val R = 20   // Suchradius im verkleinerten Bild

    fun toGray(bmp: Bitmap): Gray {
        val gw = min(240, bmp.width)
        val gh = max(1, bmp.height * gw / bmp.width)
        val sm = Bitmap.createScaledBitmap(bmp, gw, gh, true)
        val px = IntArray(gw * gh)
        sm.getPixels(px, 0, gw, 0, 0, gw, gh)
        val d = IntArray(gw * gh) {
            val c = px[it]
            (((c shr 16) and 255) * 30 + ((c shr 8) and 255) * 59 + (c and 255) * 11) / 100
        }
        return Gray(gw, gh, d, bmp.width.toFloat() / gw)
    }

    /** Verschiebung (dx, dy) in Bildpunkten des Originalbilds, oder null wenn das Gesicht verloren ging. */
    private fun move(prev: Gray, cur: Gray, f: Face): Pair<Float, Float>? {
        val cx = ((f.x1 + f.x2) / 2f / prev.scale).toInt()
        val cy = ((f.y1 + f.y2) / 2f / prev.scale).toInt()
        val half = ((f.x2 - f.x1) / prev.scale * 0.35f).toInt().coerceIn(8, 28)
        val size = half * 2
        val x0 = cx - half
        val y0 = cy - half
        if (x0 < 0 || y0 < 0 || x0 + size > prev.w || y0 + size > prev.h) return null

        var best = Int.MAX_VALUE
        var bdx = 0
        var bdy = 0
        for (dy in -R..R) for (dx in -R..R) {
            val ox = x0 + dx
            val oy = y0 + dy
            if (ox < 0 || oy < 0 || ox + size > cur.w || oy + size > cur.h) continue
            var sad = 0
            var yy = 0
            while (yy < size && sad < best) {
                val pr = (y0 + yy) * prev.w + x0
                val cr = (oy + yy) * cur.w + ox
                var xx = 0
                while (xx < size) {
                    sad += abs(prev.d[pr + xx] - cur.d[cr + xx])
                    xx += 2
                }
                yy += 2
            }
            if (sad < best) { best = sad; bdx = dx; bdy = dy }
        }
        if (best == Int.MAX_VALUE) return null
        val n = ((size + 1) / 2) * ((size + 1) / 2)
        if (best / n > 28) return null      // zu unsicher: neu suchen
        return Pair(bdx * cur.scale, bdy * cur.scale)
    }

    private fun shifted(f: Face, dx: Float, dy: Float): Face {
        val k = FloatArray(10) { if (it % 2 == 0) f.kps[it] + dx else f.kps[it] + dy }
        return Face(f.x1 + dx, f.y1 + dy, f.x2 + dx, f.y2 + dy, f.score, k)
    }

    /** Neue Positionen aller Gesichter, oder null wenn eines nicht sicher gefunden wurde. */
    fun update(prev: Gray, cur: Gray, tracks: List<Track>): List<Track>? {
        val out = ArrayList<Track>()
        for (t in tracks) {
            val m = move(prev, cur, t.face) ?: return null
            out.add(Track(shifted(t.face, m.first, m.second), t.person))
        }
        return out
    }
}

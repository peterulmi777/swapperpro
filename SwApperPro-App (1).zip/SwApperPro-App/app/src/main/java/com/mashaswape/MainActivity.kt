package com.mashaswape

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.io.File
import java.util.concurrent.CountDownLatch
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var projBox: LinearLayout
    private lateinit var preview: ImageView
    private lateinit var consent: CheckBox
    private lateinit var askFaces: CheckBox
    private lateinit var allFaces: CheckBox
    private lateinit var occCheck: CheckBox
    private lateinit var presetSpinner: Spinner
    private lateinit var perfSpinner: Spinner
    private lateinit var enhSpinner: Spinner
    private lateinit var resSpinner: Spinner
    private lateinit var qualSpinner: Spinner
    private lateinit var detSpinner: Spinner
    private lateinit var strengthEdit: EditText
    private lateinit var colorEdit: EditText
    private lateinit var photoPxEdit: EditText
    private lateinit var outPxEdit: EditText
    private lateinit var jpgEdit: EditText
    private lateinit var startEdit: EditText
    private lateinit var lenEdit: EditText
    private lateinit var fpsEdit: EditText
    private lateinit var chunkEdit: EditText

    private val dark = android.R.style.Theme_Material_Dialog_Alert
    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }
    private val needed = listOf("det_10g.onnx", "w600k_r50.onnx", "inswapper_128.onnx", "emap.bin")
    private val optional = listOf("gfpgan_1.4.onnx", "codeformer.onnx", "xseg_1.onnx")
    private val selectedPersons = ArrayList<String>()
    private var targets = listOf<Uri>()
    @Volatile private var busy = false
    @Volatile private var cfgThreads = 4
    @Volatile private var cfgNnapi = false
    private val handler = Handler(Looper.getMainLooper())
    private var projSig = ""

    private class Pick(val faces: List<Face>, val assign: IntArray, val all: Boolean)

    private class Cfg(
        val photoPx: Int, val outPx: Int, val jpg: Int, val strength: Float, val colorMatch: Float,
        val useOcc: Boolean, val enh: List<Pair<String, String>>,
        val startSec: Int, val lenSec: Int, val vMax: Int, val fps: Int, val bpp: Float,
        val detEvery: Int, val chunkSec: Int, val all: Boolean, val ask: Boolean
    )

    private val ticker = object : Runnable {
        override fun run() {
            if (Progress.running) {
                status.text = (if (Progress.paused) "PAUSIERT: " else "") + Progress.text
            }
            refreshProjects()
            handler.postDelayed(this, 1500)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            keepScreenOn = true
            setBackgroundColor(Color.BLACK)
        }
        root.addView(TextView(this).apply {
            text = "*#SwAppEr.PrO#*  v3.0"
            textSize = 22f
            setTextColor(Color.WHITE)
        })
        status = TextView(this).apply { setPadding(0, 16, 0, 16); setTextColor(Color.rgb(0, 220, 150)) }
        root.addView(status)

        consent = CheckBox(this).apply {
            text = "Ich nutze das nur mit ausdrücklicher Einwilligung der abgebildeten Personen. " +
                "Keine Täuschung, keine Rufschädigung, keine Veröffentlichung ohne Erlaubnis."
        }
        root.addView(consent)

        root.addView(button("1. Modelle importieren") { pick(1, "*/*", true, null) })
        root.addView(button("2. Quellpersonen wählen / neu anlegen") { choosePersons() })
        root.addView(button("3. Ziel wählen: Fotos und/oder Videos") {
            pick(3, "*/*", true, arrayOf("image/*", "video/*"))
        })

        askFaces = CheckBox(this).apply {
            text = "Vorher fragen, welche Gesichter getauscht werden (Tippen wechselt die Person)"
            isChecked = true
        }
        root.addView(askFaces)
        allFaces = CheckBox(this).apply { text = "Ohne Rückfrage: alle Gesichter tauschen (sonst nur das größte)" }
        root.addView(allFaces)

        root.addView(heading("Voreinstellung und Leistung"))
        presetSpinner = spinner(arrayOf("Eigene Einstellungen", "Schnell", "Ausgewogen", "Beste Qualität"))
        root.addView(presetSpinner)
        root.addView(label("Leistung (Turbo = mehr Rechenkerne)"))
        perfSpinner = spinner(
            arrayOf("Normal (4 Kerne)", "Turbo (6 Kerne)", "Max (alle Kerne)", "Max + NNAPI (experimentell)")
        )
        perfSpinner.setSelection(1)
        root.addView(perfSpinner)

        root.addView(heading("Qualität (Fotos und Videos)"))
        occCheck = CheckBox(this).apply {
            text = "Verdeckungen schützen (Hände, Brillen, Instrumente; braucht xseg_1.onnx)"
        }
        root.addView(occCheck)
        root.addView(label("Farb- und Helligkeitsanpassung in % (0 = aus, Standard 70)"))
        colorEdit = numField("70"); root.addView(colorEdit)

        root.addView(heading("Foto-Einstellungen"))
        root.addView(label("Verarbeitungsgröße, längste Seite in Pixeln (Standard 2400)"))
        photoPxEdit = numField("2400"); root.addView(photoPxEdit)
        root.addView(label("Ausgabegröße, längste Seite in Pixeln (0 = wie verarbeitet)"))
        outPxEdit = numField("0"); root.addView(outPxEdit)
        root.addView(label("JPEG-Qualität in % (50 bis 100, Standard 95)"))
        jpgEdit = numField("95"); root.addView(jpgEdit)
        root.addView(label("Gesichts-Verbesserer (nur Fotos)"))
        enhSpinner = spinner(arrayOf("Aus", "GFPGAN 1.4", "CodeFormer", "Beide (zwei Bilder zum Vergleichen)"))
        root.addView(enhSpinner)
        root.addView(label("Stärke des Verbesserers in % (Standard 80)"))
        strengthEdit = numField("80"); root.addView(strengthEdit)

        root.addView(heading("Video-Einstellungen"))
        root.addView(label("Start im Video in Sekunden (Standard 0)"))
        startEdit = numField("0"); root.addView(startEdit)
        root.addView(label("Länge in Sekunden (0 = bis zum Ende, Standard 10)"))
        lenEdit = numField("10"); root.addView(lenEdit)
        root.addView(label("Auflösung der Ausgabe"))
        resSpinner = spinner(arrayOf("480p (schnell)", "720p", "1080p (langsam)"))
        resSpinner.setSelection(1)
        root.addView(resSpinner)
        root.addView(label("Bilder pro Sekunde (5 bis 30, weniger = schneller)"))
        fpsEdit = numField("10"); root.addView(fpsEdit)
        root.addView(label("Videoqualität (Dateigröße)"))
        qualSpinner = spinner(arrayOf("Niedrig", "Mittel", "Hoch"))
        qualSpinner.setSelection(1)
        root.addView(qualSpinner)
        root.addView(label("Gesichtssuche (nachverfolgen spart Zeit)"))
        detSpinner = spinner(arrayOf("Jedes Bild (genau)", "Jedes 2. Bild", "Jedes 3. Bild (schnell)"))
        root.addView(detSpinner)
        root.addView(label("Teilstück-Länge in Sekunden (nach Abbruch geht es beim nächsten Teil weiter)"))
        chunkEdit = numField("60"); root.addView(chunkEdit)

        root.addView(button("TESTBILD (ein Bild tauschen und ansehen)") { runTest() })
        root.addView(button("TAUSCHEN (Fotos sofort, Videos im Hintergrund)") { runSwap() })

        preview = ImageView(this).apply {
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(preview)

        root.addView(heading("Video-Projekte"))
        val ctl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ctl.addView(button("Pause / Weiter") { Progress.paused = !Progress.paused })
        ctl.addView(button("Stopp") { Progress.stop = true; Progress.paused = false })
        root.addView(ctl)
        projBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(projBox)

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(root) })

        onSelect(presetSpinner) { applyPreset(it) }
        onSelect(perfSpinner) { cfgThreads = threadsFor(it); cfgNnapi = it == 3 }
        cfgThreads = threadsFor(1)
        say(modelStatus())
    }

    // ---------------- kleine Helfer ----------------
    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 17f
        setTextColor(Color.rgb(0, 200, 150))
        setPadding(0, 36, 0, 0)
    }

    private fun label(t: String) = TextView(this).apply { text = t; setPadding(0, 20, 0, 0) }

    private fun numField(v: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(v)
    }

    private fun spinner(items: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun onSelect(s: Spinner, f: (Int) -> Unit) {
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { f(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun threadsFor(pos: Int): Int =
        when (pos) { 0 -> 4; 1 -> 6; else -> Runtime.getRuntime().availableProcessors() }

    private fun say(s: String) = runOnUiThread { status.text = s }

    private fun intOf(e: EditText, def: Int, lo: Int, hi: Int): Int =
        e.text.toString().toIntOrNull()?.coerceIn(lo, hi) ?: def

    private fun modelStatus(): String {
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) return "Fehlende Modelle: ${missing.joinToString(", ")}"
        val extra = optional.filter { File(modelDir, it).exists() }
        return "Modelle vorhanden. Zusatz: " + if (extra.isEmpty()) "keine." else extra.joinToString(", ") + "."
    }

    private fun applyPreset(pos: Int) {
        if (pos == 0) return
        val v = when (pos) {
            1 -> intArrayOf(1600, 90, 0, 60, 0, 8, 0, 2, 0, 2)   // schnell
            2 -> intArrayOf(2400, 95, 1, 70, 1, 10, 1, 1, 1, 1)  // ausgewogen
            else -> intArrayOf(3600, 98, 3, 80, 2, 15, 2, 0, 1, 2) // beste Qualität
        }
        photoPxEdit.setText(v[0].toString())
        jpgEdit.setText(v[1].toString())
        enhSpinner.setSelection(v[2])
        colorEdit.setText(v[3].toString())
        resSpinner.setSelection(v[4])
        fpsEdit.setText(v[5].toString())
        qualSpinner.setSelection(v[6])
        detSpinner.setSelection(v[7])
        occCheck.isChecked = v[8] == 1
        perfSpinner.setSelection(v[9])
    }

    // ---------------- Auswahl und Import ----------------
    private fun pick(req: Int, mime: String, multi: Boolean, mimes: Array<String>?) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multi)
            if (mimes != null) putExtra(Intent.EXTRA_MIME_TYPES, mimes)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (e: Exception) { }
        }
        when (req) {
            1 -> importModels(uris)
            2 -> createPerson(uris)
            3 -> { targets = uris; say("${uris.size} Ziel-Datei(en) gewählt.") }
        }
    }

    private fun displayName(u: Uri): String? =
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }

    private fun querySize(u: Uri): Long =
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0) c.getLong(i) else -1L
            } else -1L
        } ?: -1L

    /** Erkennt auch umbenannte Downloads wie "gfpgan_1.4 (1).onnx". */
    private fun canonicalName(raw: String): String? {
        val clean = raw.replace(Regex(" \\(\\d+\\)"), "")
        return (needed + optional).firstOrNull { it == clean }
    }

    private fun importModels(uris: List<Uri>) {
        Thread {
            try {
                for (u in uris) {
                    val raw = displayName(u) ?: continue
                    val name = canonicalName(raw)
                    if (name == null) { say("Übersprungen: $raw"); continue }
                    val size = querySize(u)
                    if (size > 0 && modelDir.usableSpace < size + 100L * 1024 * 1024) {
                        say("Zu wenig Speicher für $name. Bitte Platz schaffen und erneut importieren.")
                        continue
                    }
                    say("Kopiere $name ...")
                    val dst = File(modelDir, name)
                    try {
                        contentResolver.openInputStream(u)?.use { inp ->
                            dst.outputStream().use { out -> inp.copyTo(out) }
                        }
                    } catch (e: Throwable) {
                        dst.delete()
                        say("Fehler bei $name (halbe Datei gelöscht): ${e.message}")
                    }
                }
                EngineHolder.reset()
                say(modelStatus())
            } catch (e: Throwable) {
                say("Fehler beim Import: ${e.message}")
            }
        }.start()
    }

    // ---------------- Personen ----------------
    private fun askText(title: String, cb: (String) -> Unit) {
        val et = EditText(this)
        AlertDialog.Builder(this, dark).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> cb(et.text.toString().trim()) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun choosePersons() {
        val names = Store.personNames(this)
        val checked = BooleanArray(names.size) { selectedPersons.contains(names[it]) }
        AlertDialog.Builder(this, dark)
            .setTitle(if (names.isEmpty()) "Noch keine Personen gespeichert" else "Quellpersonen wählen")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, on -> checked[i] = on }
            .setPositiveButton("OK") { _, _ ->
                selectedPersons.clear()
                for (i in names.indices) if (checked[i]) selectedPersons.add(names[i])
                say("Quellpersonen: " + if (selectedPersons.isEmpty()) "keine" else selectedPersons.joinToString(", "))
            }
            .setNeutralButton("Neue Person anlegen") { _, _ -> pick(2, "image/*", true, null) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun engine(): FaceEngine {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putInt("threads", cfgThreads).putBoolean("nnapi", cfgNnapi).apply()
        return EngineHolder.get(modelDir, cfgThreads, cfgNnapi)
    }

    private fun createPerson(uris: List<Uri>) {
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) { say("Fehlende Modelle: ${missing.joinToString(", ")}"); return }
        askText("Name der neuen Person") { name ->
            if (name.isNotEmpty()) {
                Thread {
                    try {
                        say("Lade Modelle ...")
                        val eng = engine()
                        val embs = ArrayList<FloatArray>()
                        for ((i, u) in uris.withIndex()) {
                            say("Foto ${i + 1}/${uris.size} ...")
                            val b = load(u, 2400) ?: continue
                            val f = eng.detect(b).maxByOrNull { it.area } ?: continue
                            embs.add(eng.embed(b, f))
                        }
                        if (embs.isEmpty()) {
                            say("In den Fotos wurde kein Gesicht gefunden.")
                        } else {
                            val clean = Store.savePerson(this, name, eng.makeLatent(embs))
                            if (!selectedPersons.contains(clean)) selectedPersons.add(clean)
                            say("Person '$clean' gespeichert und ausgewählt (${embs.size} Foto(s)).")
                        }
                    } catch (e: Throwable) {
                        say("Fehler: ${e.message}")
                    }
                }.start()
            }
        }
    }

    private fun loadLatents(): List<FloatArray>? {
        val l = selectedPersons.map { Store.loadPerson(this, it) }
        return if (l.isEmpty() || l.any { it == null }) null else l.filterNotNull()
    }

    // ---------------- Bilder laden / speichern ----------------
    private fun isVideo(u: Uri): Boolean = contentResolver.getType(u)?.startsWith("video/") == true

    private fun scaleTo(b: Bitmap, px: Int): Bitmap {
        val m = max(b.width, b.height)
        if (px <= 0 || m == px) return b
        val s = px.toFloat() / m
        return Bitmap.createScaledBitmap(
            b, max(1, (b.width * s).toInt()), max(1, (b.height * s).toInt()), true
        )
    }

    private fun load(u: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: return null
        val orient = contentResolver.openInputStream(u)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        } ?: 1
        val deg = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        val rotated = if (deg == 0f) bmp else {
            val m = Matrix().apply { postRotate(deg) }
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return if (max(rotated.width, rotated.height) > maxSide) scaleTo(rotated, maxSide) else rotated
    }

    private fun videoFrame(u: Uri, startSec: Int): Bitmap? {
        val m = MediaMetadataRetriever()
        return try {
            m.setDataSource(this, u)
            val f = m.getFrameAtTime(startSec * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST)
            f?.copy(Bitmap.Config.ARGB_8888, true)?.let { scaleTo(it, 1280).copy(Bitmap.Config.ARGB_8888, true) }
        } catch (e: Exception) {
            null
        } finally {
            m.release()
        }
    }

    private fun save(b: Bitmap, tag: String, quality: Int) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "swapperpro_${System.currentTimeMillis()}_$tag.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SwApperPro")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    }

    // ---------------- Gesichter auswählen ----------------
    private fun askWhichFaces(b: Bitmap, faces: List<Face>, label: String): Pick? {
        val names = ArrayList(selectedPersons)
        val latch = CountDownLatch(1)
        var result: Pick? = null
        runOnUiThread {
            val v = FacePickView(this, b, faces, names)
            val holder = ScrollView(this).apply { addView(v) }
            val hint = if (names.size > 1) "Tippen wechselt die Person" else "grün = wird getauscht"
            AlertDialog.Builder(this, dark)
                .setTitle("$label: Gesichter antippen ($hint)")
                .setView(holder)
                .setPositiveButton("Tauschen") { _, _ -> result = Pick(faces, v.assign.copyOf(), false); latch.countDown() }
                .setNeutralButton("Alle") { _, _ -> result = Pick(faces, IntArray(faces.size) { 0 }, true); latch.countDown() }
                .setNegativeButton("Überspringen") { _, _ -> result = null; latch.countDown() }
                .setCancelable(false)
                .show()
        }
        latch.await()
        return result
    }

    private fun chooseFaces(b: Bitmap, found: List<Face>, label: String, c: Cfg): List<Pair<Face, Int>> {
        if (c.ask) {
            val p = askWhichFaces(b, found, label) ?: return emptyList()
            return found.indices.filter { p.assign[it] >= 0 }.map { found[it] to p.assign[it] }
        }
        return if (c.all) found.map { it to 0 } else found.take(1).map { it to 0 }
    }

    // ---------------- Einstellungen lesen ----------------
    private fun readCfg(): Cfg {
        val enh: List<Pair<String, String>> = when (enhSpinner.selectedItemPosition) {
            1 -> listOf("gfpgan_1.4.onnx" to "gfpgan")
            2 -> listOf("codeformer.onnx" to "codeformer")
            3 -> listOf("gfpgan_1.4.onnx" to "gfpgan", "codeformer.onnx" to "codeformer")
            else -> emptyList()
        }
        return Cfg(
            photoPx = intOf(photoPxEdit, 2400, 480, 6000),
            outPx = intOf(outPxEdit, 0, 0, 8000),
            jpg = intOf(jpgEdit, 95, 50, 100),
            strength = intOf(strengthEdit, 80, 0, 100) / 100f,
            colorMatch = intOf(colorEdit, 70, 0, 100) / 100f,
            useOcc = occCheck.isChecked,
            enh = enh,
            startSec = intOf(startEdit, 0, 0, 100000),
            lenSec = intOf(lenEdit, 10, 0, 100000),
            vMax = when (resSpinner.selectedItemPosition) { 0 -> 854; 1 -> 1280; else -> 1920 },
            fps = intOf(fpsEdit, 10, 5, 30),
            bpp = when (qualSpinner.selectedItemPosition) { 0 -> 0.10f; 1 -> 0.17f; else -> 0.30f },
            detEvery = detSpinner.selectedItemPosition + 1,
            chunkSec = intOf(chunkEdit, 60, 10, 3600),
            all = allFaces.isChecked,
            ask = askFaces.isChecked
        )
    }

    private fun ready(c: Cfg): Boolean {
        if (!consent.isChecked) { say("Bitte zuerst die Einwilligung bestätigen."); return false }
        if (selectedPersons.isEmpty()) { say("Bitte bei 2. mindestens eine Quellperson wählen oder anlegen."); return false }
        if (targets.isEmpty()) { say("Bitte bei 3. ein Ziel wählen."); return false }
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) { say("Fehlende Modelle: ${missing.joinToString(", ")}"); return false }
        val missEnh = c.enh.map { it.first }.filter { !File(modelDir, it).exists() }
        if (missEnh.isNotEmpty()) { say("Verbesserer-Datei fehlt: ${missEnh.joinToString(", ")} (Schritt 1)."); return false }
        if (c.useOcc && !File(modelDir, "xseg_1.onnx").exists()) {
            say("Verdeckungs-Schutz braucht xseg_1.onnx (Schritt 1)."); return false
        }
        return true
    }

    // ---------------- Testbild ----------------
    private fun runTest() {
        if (busy) return
        val c = readCfg()
        if (!ready(c)) return
        busy = true
        Thread {
            try {
                say("Testbild: Modelle laden ...")
                val eng = engine()
                val latents = loadLatents() ?: run { say("Quellperson fehlt."); return@Thread }
                val u = targets[0]
                val bmp = (if (isVideo(u)) videoFrame(u, c.startSec) else load(u, c.photoPx))
                    ?: run { say("Ziel nicht lesbar."); return@Thread }
                val found = eng.detect(bmp).sortedByDescending { it.area }
                if (found.isEmpty()) { say("Testbild: kein Gesicht gefunden."); return@Thread }
                val chosen = chooseFaces(bmp, found, "Testbild", c)
                if (chosen.isEmpty()) { say("Testbild abgebrochen."); return@Thread }
                say("Testbild: tausche ...")
                var out = bmp
                for ((f, pi) in chosen) out = eng.swap(out, f, latents[pi.coerceIn(0, latents.size - 1)], c.colorMatch, c.useOcc)
                if (!isVideo(u) && c.enh.isNotEmpty()) {
                    say("Testbild: Verbesserer läuft ...")
                    for ((f, _) in chosen) out = eng.enhance(out, f, c.enh[0].first, c.strength)
                }
                val shown = out
                runOnUiThread { preview.setImageBitmap(shown) }
                say("Testbild fertig. Passt es? Dann TAUSCHEN. Sonst Einstellungen ändern und neu testen.")
            } catch (e: Throwable) {
                say("Fehler: ${e.message}")
            } finally {
                busy = false
            }
        }.start()
    }

    // ---------------- Tauschen ----------------
    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 9)
        }
    }

    private fun startWork() {
        requestNotifications()
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putInt("threads", cfgThreads).putBoolean("nnapi", cfgNnapi).apply()
        startForegroundService(Intent(this, SwapService::class.java))
    }

    private fun runSwap() {
        if (busy) return
        val c = readCfg()
        if (!ready(c)) return
        busy = true
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "swapperpro:ui")
        wl.acquire(6L * 60 * 60 * 1000)
        Thread {
            var projects = 0
            try {
                say("Modelle laden (beim ersten Mal dauert das) ...")
                val eng = engine()
                val latents = loadLatents() ?: run { say("Quellperson fehlt."); return@Thread }
                var last: Bitmap? = null
                var done = 0
                for ((i, u) in targets.withIndex()) {
                    val label = "Ziel ${i + 1}/${targets.size}"
                    if (isVideo(u)) {
                        if (makeProject(eng, u, i, label, c)) projects++
                    } else {
                        val out = photoJob(eng, latents, u, i, label, c)
                        if (out != null) { last = out; done++ }
                    }
                }
                val shown = last
                if (shown != null) runOnUiThread { preview.setImageBitmap(shown) }
                say("Fertig: $done Foto(s) gespeichert (Bilder/SwApperPro). " +
                    if (projects > 0) "$projects Video(s) laufen im Hintergrund." else "")
            } catch (e: Throwable) {
                say("Fehler: ${e.message}")
            } finally {
                if (wl.isHeld) wl.release()
                busy = false
            }
            if (projects > 0) runOnUiThread { startWork() }
        }.start()
    }

    /** Ein Foto komplett bearbeiten und speichern. Gibt das letzte Ergebnis zurück oder null. */
    private fun photoJob(
        eng: FaceEngine, latents: List<FloatArray>, u: Uri, i: Int, label: String, c: Cfg
    ): Bitmap? {
        say("$label: Gesichter suchen ...")
        val b = load(u, c.photoPx) ?: return null
        val found = eng.detect(b).sortedByDescending { it.area }
        if (found.isEmpty()) { say("$label: kein Gesicht gefunden."); return null }
        val chosen = chooseFaces(b, found, label, c)
        if (chosen.isEmpty()) return null

        say("$label: Gesicht wird getauscht ...")
        var swapped = b
        for ((f, pi) in chosen) {
            swapped = eng.swap(swapped, f, latents[pi.coerceIn(0, latents.size - 1)], c.colorMatch, c.useOcc)
        }
        if (c.enh.isEmpty()) {
            val outBmp = scaleTo(swapped, c.outPx)
            save(outBmp, "$i", c.jpg)
            return outBmp
        }
        var last: Bitmap? = null
        for ((file, tag) in c.enh) {
            say("$label: Verbesserer $tag läuft (kann etwas dauern) ...")
            var out = swapped
            for ((f, _) in chosen) out = eng.enhance(out, f, file, c.strength)
            val outBmp = scaleTo(out, c.outPx)
            save(outBmp, "${i}_$tag", c.jpg)
            last = outBmp
        }
        return last
    }

    /** Legt für ein Video einen Auftrag an (Gesichtsauswahl am Startbild). */
    private fun makeProject(eng: FaceEngine, u: Uri, i: Int, label: String, c: Cfg): Boolean {
        var refs: List<FloatArray> = emptyList()
        var refAssign: List<Int> = emptyList()
        var all = c.all
        if (c.ask) {
            say("$label: Startbild laden ...")
            val fb = videoFrame(u, c.startSec)
            if (fb == null) { say("$label: Startbild nicht lesbar."); return false }
            val ff = eng.detect(fb).sortedByDescending { it.area }
            if (ff.isEmpty()) { say("$label: im Startbild kein Gesicht gefunden."); return false }
            val p = askWhichFaces(fb, ff, "$label (Video)") ?: return false
            if (p.all) {
                all = true
            } else {
                val idx = ff.indices.filter { p.assign[it] >= 0 }
                if (idx.isEmpty()) return false
                refs = idx.map { eng.embed(fb, ff[it]) }
                refAssign = idx.map { p.assign[it] }
            }
        }
        val id = System.currentTimeMillis().toString() + "_" + i
        val proj = Project(
            id = id, name = displayName(u) ?: "Video", uri = u.toString(),
            startSec = c.startSec, lenSec = c.lenSec, maxSide = c.vMax, fps = c.fps, bpp = c.bpp,
            detectEvery = c.detEvery, colorMatch = c.colorMatch, useOcc = c.useOcc, chunkSec = c.chunkSec,
            personNames = ArrayList(selectedPersons), allFaces = all, refAssign = refAssign,
            state = "wartet"
        )
        Store.save(this, proj)
        Store.saveRefs(this, id, refs)
        return true
    }

    // ---------------- Projektliste ----------------
    private fun smallBtn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { f() }
    }

    private fun refreshProjects() {
        val list = Store.all(this)
        val sig = list.joinToString("|") { "${it.id}:${it.state}:${it.doneChunks}:${it.msg}" } +
            Progress.running + Progress.paused
        if (sig == projSig) return
        projSig = sig
        projBox.removeAllViews()
        for (p in list) {
            val running = p.state == "läuft" && Progress.running
            val stale = p.state == "läuft" && !Progress.running
            val st = if (stale) "unterbrochen" else p.state
            projBox.addView(TextView(this).apply {
                text = "${p.name}\n$st, Teil ${p.doneChunks}/${p.totalChunks} ${p.msg}" +
                    if (p.state == "fertig") "\nFertig: Filme/SwApperPro" else ""
                setPadding(0, 20, 0, 0)
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (p.state != "fertig" && !running) {
                row.addView(smallBtn(if (p.state == "wartet") "Start" else "Fortsetzen") {
                    p.state = "wartet"
                    p.msg = ""
                    Store.save(this, p)
                    projSig = ""
                    startWork()
                })
            }
            if (!running) {
                row.addView(smallBtn("Löschen") {
                    Store.delete(this, p.id)
                    projSig = ""
                    refreshProjects()
                })
            }
            projBox.addView(row)
        }
    }
}

package com.mashaswape

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import java.io.File
import kotlin.math.min

/**
 * Hintergrunddienst für Videos: läuft mit Benachrichtigung weiter, auch wenn die App geschlossen ist.
 * Fertige Teilstücke bleiben gespeichert; nach einem Abbruch geht es dort weiter.
 */
class SwapService : Service() {
    private val channel = "swapperpro"
    private var wl: PowerManager.WakeLock? = null
    private var runFrames = 0
    private var runStart = 0L
    private var lastNote = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "PAUSE" -> {
                Progress.paused = !Progress.paused
                postNote(Progress.text, Progress.pct)
            }
            "STOP" -> {
                Progress.stop = true
                Progress.paused = false
            }
            else -> {
                val nm = getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(
                    NotificationChannel(channel, "Verarbeitung", NotificationManager.IMPORTANCE_LOW)
                )
                try {
                    startForeground(
                        1, buildNote("Starte ...", 0),
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    )
                } catch (e: Exception) {
                    // läuft dann ohne Vordergrund-Status weiter
                }
                if (!Progress.running) {
                    Progress.running = true
                    Thread { work() }.start()
                }
            }
        }
        return START_STICKY
    }

    private fun buildNote(text: String, pct: Int): Notification {
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, SwapService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val pauseI = PendingIntent.getService(
            this, 2, Intent(this, SwapService::class.java).setAction("PAUSE"), PendingIntent.FLAG_IMMUTABLE
        )
        val openI = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("*#SwAppEr.PrO#*")
            .setContentText(text)
            .setProgress(100, pct, false)
            .setOngoing(true)
            .setContentIntent(openI)
            .addAction(android.R.drawable.ic_media_pause, if (Progress.paused) "Weiter" else "Pause", pauseI)
            .addAction(android.R.drawable.ic_delete, "Stopp", stopI)
            .build()
    }

    private fun postNote(text: String, pct: Int) {
        try {
            getSystemService(NotificationManager::class.java).notify(1, buildNote(text, pct))
        } catch (e: Exception) {
        }
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        if (now - lastNote > 1500) {
            lastNote = now
            postNote(Progress.text, Progress.pct)
        }
    }

    private fun fmt(sec: Long): String = when {
        sec >= 3600 -> "${sec / 3600} Std ${(sec % 3600) / 60} Min"
        sec >= 60 -> "${sec / 60} Min"
        else -> "$sec s"
    }

    private fun fail(p: Project, msg: String) {
        p.state = "fehler"
        p.msg = msg
        Store.save(this, p)
    }

    private fun work() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "swapperpro:svc")
        wl?.acquire(12L * 60 * 60 * 1000)
        Progress.stop = false
        Progress.paused = false
        var summary = "Verarbeitung beendet."
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY)
            for (p in Store.all(this)) {
                if (p.state == "läuft") { p.state = "wartet"; Store.save(this, p) }
            }
            val cfg = getSharedPreferences("cfg", MODE_PRIVATE)
            val eng = EngineHolder.get(
                File(filesDir, "models"), cfg.getInt("threads", 4), cfg.getBoolean("nnapi", false)
            )
            runStart = System.currentTimeMillis()
            runFrames = 0
            while (!Progress.stop) {
                val p = Store.all(this).firstOrNull { it.state == "wartet" } ?: break
                runProject(p, eng)
            }
            if (Progress.stop) summary = "Gestoppt. Du kannst in der App fortsetzen."
        } catch (e: Throwable) {
            Progress.text = "Fehler: ${e.message}"
            summary = "Fehler: ${e.message}"
        } finally {
            Progress.running = false
            try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) {}
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) {}
            try {
                val n = Notification.Builder(this, channel)
                    .setSmallIcon(android.R.drawable.ic_popup_sync)
                    .setContentTitle("*#SwAppEr.PrO#*")
                    .setContentText(summary)
                    .setAutoCancel(true)
                    .build()
                getSystemService(NotificationManager::class.java).notify(2, n)
            } catch (e: Exception) {}
            stopSelf()
        }
    }

    private fun runProject(p: Project, eng: FaceEngine) {
        p.state = "läuft"
        p.msg = ""
        Store.save(this, p)
        val uri = Uri.parse(p.uri)
        val plan = VideoPipeline.plan(this, uri, p)
        if (plan == null) { fail(p, "Video nicht lesbar (Zugriff verloren?)"); return }

        val loaded = p.personNames.map { Store.loadPerson(this, it) }
        if (loaded.isEmpty() || loaded.any { it == null }) { fail(p, "Quellperson fehlt"); return }
        val latents = loaded.filterNotNull()
        val refs = Store.loadRefs(this, p.id)
        p.totalChunks = plan.chunks
        Store.save(this, p)
        val dir = Store.projDir(this, p.id)

        for (k in p.doneChunks until plan.chunks) {
            val first = k * plan.chunkFrames
            val frames = min(plan.chunkFrames, plan.total - first)
            val tmp = File(dir, "chunk_$k.tmp")
            val ok = VideoPipeline.processChunk(
                this, uri, eng, latents, refs, p, plan, first, frames, tmp
            ) { n ->
                runFrames++
                val done = first + n
                Progress.pct = done * 100 / plan.total
                val el = (System.currentTimeMillis() - runStart) / 1000.0
                val remain = (el / runFrames * (plan.total - done)).toLong()
                Progress.text = "${p.name}: Bild $done/${plan.total}, Teil ${k + 1}/${plan.chunks}, noch ca. ${fmt(remain)}"
                tick()
            }
            if (!ok) {
                p.state = if (Progress.stop) "gestoppt" else "fehler"
                if (p.state == "fehler" && p.msg.isEmpty()) p.msg = "Teilstück fehlgeschlagen"
                Store.save(this, p)
                return
            }
            tmp.renameTo(File(dir, "chunk_$k.mp4"))
            p.doneChunks = k + 1
            Store.save(this, p)
        }

        Progress.text = "${p.name}: füge Teilstücke zusammen ..."
        postNote(Progress.text, 99)
        val files = (0 until plan.chunks).map { File(dir, "chunk_$it.mp4") }
        val durs = (0 until plan.chunks).map { k ->
            min(plan.chunkFrames, plan.total - k * plan.chunkFrames) * 1_000_000L / p.fps
        }
        val finalFile: File
        if (files.size == 1) {
            finalFile = files[0]
        } else {
            finalFile = File(cacheDir, "final_${p.id}.mp4")
            if (!VideoPipeline.concat(files, durs, finalFile)) { fail(p, "Zusammenfügen fehlgeschlagen"); return }
        }

        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "swapperpro_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SwApperPro")
        }
        val dst = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
        if (dst == null) { fail(p, "Speichern fehlgeschlagen"); return }
        contentResolver.openOutputStream(dst)?.use { out ->
            finalFile.inputStream().use { it.copyTo(out) }
        }
        p.outUri = dst.toString()
        p.state = "fertig"
        Store.save(this, p)
        for (f in files) f.delete()
        if (finalFile != files[0]) finalFile.delete()
    }
}
